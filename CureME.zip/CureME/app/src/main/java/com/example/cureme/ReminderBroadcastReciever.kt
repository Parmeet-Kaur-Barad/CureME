package com.example.cureme

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class ReminderBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Handle the broadcast receiver logic here
        Log.d("ReminderBroadcast", "Received reminder broadcast")

        // You can access the extras from the intent if needed
        val extras = intent.extras
        if (extras != null) {
            // Extract any extra data from the intent
            val med = extras.getString("med")
            val time = extras.getString("time")
            val everyday = extras.getBoolean("everyday")
            val s = extras.getBoolean("s")
            val m = extras.getBoolean("m")
            val t = extras.getBoolean("t")
            val w = extras.getBoolean("w")
            val th = extras.getBoolean("th")
            val f = extras.getBoolean("f")
            val s2 = extras.getBoolean("s2")

            // Log the extracted data
            Log.d("ReminderBroadcast", "Medicine Name: $med")
            Log.d("ReminderBroadcast", "Set Time: $time")
            Log.d("ReminderBroadcast", "Everyday: $everyday")
            Log.d("ReminderBroadcast", "S: $s")
            Log.d("ReminderBroadcast", "M: $m")
            Log.d("ReminderBroadcast", "T: $t")
            Log.d("ReminderBroadcast", "W: $w")
            Log.d("ReminderBroadcast", "Th: $th")
            Log.d("ReminderBroadcast", "F: $f")
            Log.d("ReminderBroadcast", "S: $s2")
        }
    }
}
