package com.example.cureme

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cureme.R.id.records

class Medicine : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medicine)

        var b1 = findViewById<Button>(R.id.setreminder)
        var b2 = findViewById<Button>(records)
        var med = findViewById<EditText>(R.id.InputMed1)
        var time = findViewById<EditText>(R.id.Time1)
        var med1 = findViewById<EditText>(R.id.InputMed2)
        var time1 = findViewById<EditText>(R.id.Time2)

        b1.setOnClickListener {
            val intent = Intent(this,setreminder::class.java)
            startActivity(intent)
            finish()
        }
    }
}
