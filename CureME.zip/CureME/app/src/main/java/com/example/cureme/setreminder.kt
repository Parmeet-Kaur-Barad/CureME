package com.example.cureme

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class setreminder : AppCompatActivity() {
    private lateinit var inputMed: EditText
    private lateinit var inputTime: EditText
    private lateinit var checkBox: CheckBox
    private lateinit var checkBox1: CheckBox
    private lateinit var checkBox2: CheckBox
    private lateinit var checkBox3: CheckBox
    private lateinit var checkBox4: CheckBox
    private lateinit var checkBox5: CheckBox
    private lateinit var checkBox6: CheckBox
    private lateinit var checkBox7: CheckBox
    private lateinit var btn: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setreminder)

        inputMed = findViewById(R.id.InputMed)
        inputTime = findViewById(R.id.InputTime)
        checkBox = findViewById(R.id.CheckBox)
        checkBox1 = findViewById(R.id.CheckBox1)
        checkBox2 = findViewById(R.id.CheckBox2)
        checkBox3 = findViewById(R.id.CheckBox3)
        checkBox4 = findViewById(R.id.CheckBox4)
        checkBox5 = findViewById(R.id.CheckBox5)
        checkBox6 = findViewById(R.id.CheckBox6)
        checkBox7 = findViewById(R.id.CheckBox7)
        btn = findViewById(R.id.Btn)

        btn.setOnClickListener { view: View ->
            val med = inputMed.text.toString()
            val time = inputTime.text.toString()
            val everyday = checkBox.isChecked
            val s = checkBox1.isChecked
            val m = checkBox2.isChecked
            val t = checkBox3.isChecked
            val w = checkBox4.isChecked
            val th = checkBox5.isChecked
            val f = checkBox6.isChecked
            val s2 = checkBox7.isChecked

            // Create an intent for the broadcast receiver
            val intent = Intent(this, ReminderBroadcastReceiver::class.java)

            // Add any extra data to the intent
            intent.putExtra("med", med)
            intent.putExtra("time", time)
            intent.putExtra("everyday", everyday)
            intent.putExtra("s", s)
            intent.putExtra("m", m)
            intent.putExtra("t", t)
            intent.putExtra("w", w)
            intent.putExtra("th", th)
            intent.putExtra("f", f)
            intent.putExtra("s2", s2)

            // Send the broadcast
            sendBroadcast(intent)

            // Log the data before sending the broadcast (optional)
            Log.d("setreminder", "Medicine Name: $med")
            Log.d("setreminder", "Set Time: $time")
            Log.d("setreminder", "Everyday: $everyday")
            Log.d("setreminder", "S: $s")
            Log.d("setreminder", "M: $m")
            Log.d("setreminder", "T: $t")
            Log.d("setreminder", "W: $w")
            Log.d("setreminder", "Th: $th")
            Log.d("setreminder", "F: $f")
            Log.d("setreminder", "S: $s2")
        }
    }
}

